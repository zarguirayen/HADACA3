def program(mix=None, ref=None, **kwargs):

  import numpy as np
  import pandas as pd
  from scipy.optimize import nnls

  # Hyperparams to tune
  EPS = 1e-9
  N_RNA = 1800     # try 1200 / 1800 / 2500
  N_MET = 9000     # try 6000 / 9000 / 12000
  USE_WEIGHT = True

  def select_top_var(ref_df, n_keep):
      if n_keep is None or n_keep >= ref_df.shape[0]:
          return ref_df.index
      v = ref_df.var(axis=1)
      return v.sort_values(ascending=False).head(n_keep).index

  def prep_align(mix_df, ref_df, n_keep=None, log1p=False):
      idx = mix_df.index.intersection(ref_df.index)
      mix_df = mix_df.loc[idx, :].astype(float)
      ref_df = ref_df.loc[idx, :].astype(float)

      keep = select_top_var(ref_df, n_keep)
      keep = keep.intersection(mix_df.index)
      mix_df = mix_df.loc[keep, :]
      ref_df = ref_df.loc[keep, :]

      if log1p:
          mix_df = np.log1p(mix_df)
          ref_df = np.log1p(ref_df)

      # Feature weighting: emphasize discriminative features (std across cell types)
      if USE_WEIGHT:
          std = ref_df.std(axis=1).to_numpy(dtype=float)
          med = float(np.median(std) + 1e-12)
          w = std / med
          w = np.clip(w, 0.2, 5.0)
          mix_df = mix_df.mul(w, axis=0)
          ref_df = ref_df.mul(w, axis=0)

      # Scale by mean ref to stabilize magnitudes
      scale = ref_df.mean(axis=1).replace(0, np.nan).fillna(1.0)
      mix_df = mix_df.div(scale, axis=0)
      ref_df = ref_df.div(scale, axis=0)

      return mix_df, ref_df

  def nnls_deconv(mix_df, ref_df):
      R = ref_df.to_numpy(dtype=float)  # (features x celltypes)
      celltypes = list(ref_df.columns)

      props = []
      errs = []
      for s in mix_df.columns:
          y = mix_df[s].to_numpy(dtype=float)
          p, _ = nnls(R, y)
          p = np.maximum(p, 0.0) + EPS
          p = p / p.sum()

          yhat = R @ p
          err = np.linalg.norm(yhat - y) / (np.linalg.norm(y) + 1e-12)

          props.append(p)
          errs.append(err)

      P = pd.DataFrame(props, index=mix_df.columns, columns=celltypes).T
      E = pd.Series(errs, index=mix_df.columns)
      return P, E

  def fuse_by_error(P1, E1, P2, E2, all_cols):
      # Higher weight to the method with lower error (soft switch)
      common = P1.columns.intersection(P2.columns)
      if len(common) == 0:
          out = P1.reindex(columns=all_cols)
          out = out.clip(lower=EPS)
          out = out.div(out.sum(axis=0), axis=1)
          return out

      P1c = P1.loc[:, common]
      P2c = P2.loc[:, common]
      e1 = E1.loc[common]
      e2 = E2.loc[common]

      w1 = e2 / (e1 + e2 + 1e-12)  # if method2 bad -> trust method1
      outc = P1c.mul(w1, axis=1) + P2c.mul(1.0 - w1, axis=1)

      outc = outc.clip(lower=EPS)
      outc = outc.div(outc.sum(axis=0), axis=1)

      out = outc.reindex(columns=all_cols)
      out = out.clip(lower=EPS)
      out = out.div(out.sum(axis=0), axis=1)
      return out

  # --- RNA: two variants (raw and log1p), then fuse ---
  mix_rna_raw, ref_rna_raw = prep_align(mix, ref, n_keep=N_RNA, log1p=False)
  P_rna_raw, E_rna_raw = nnls_deconv(mix_rna_raw, ref_rna_raw)

  mix_rna_log, ref_rna_log = prep_align(mix, ref, n_keep=N_RNA, log1p=True)
  P_rna_log, E_rna_log = nnls_deconv(mix_rna_log, ref_rna_log)

  P_rna = fuse_by_error(P_rna_log, E_rna_log, P_rna_raw, E_rna_raw, mix.columns)

  # --- Methylation ---
  mix_met = kwargs.get("mix_met", None)
  ref_met = kwargs.get("ref_met", None)

  if mix_met is None or ref_met is None:
      prop = P_rna
  else:
      mix_m, ref_m = prep_align(mix_met, ref_met, n_keep=N_MET, log1p=False)
      P_met, E_met = nnls_deconv(mix_m, ref_m)

      # Need RNA errors for fusion: approximate with the chosen RNA error (use raw errors as proxy)
      # Recompute RNA error on the fused RNA by mixing E_rna_log and E_rna_raw similarly
      # Simpler: use min of the two RNA errors per sample
      E_rna = pd.concat([E_rna_log, E_rna_raw], axis=1).min(axis=1)

      prop = fuse_by_error(P_rna, E_rna, P_met, E_met, mix.columns)

  prop.columns = mix.columns
  return prop
  ##
  ## YOUR CODE ENDS HERE
  ##
