def program(mix=None, ref=None, **kwargs):

  import numpy as np
  import pandas as pd
  from scipy.optimize import nnls

  EPS = 1e-6
  N_RNA = 3000
  N_MET = 20000
  MET_W = 1.2  # try 1.0 then 1.2 then 1.5

  def normalize(P):
      P = P.clip(lower=EPS)
      P = P.div(P.sum(axis=0), axis=1)
      P = P.fillna(1.0 / P.shape[0])
      P = P.div(P.sum(axis=0), axis=1)
      return P

  def select_top_var(ref_df, n_keep):
      if n_keep is None or n_keep >= ref_df.shape[0]:
          return ref_df.index
      v = ref_df.var(axis=1)
      return v.sort_values(ascending=False).head(n_keep).index

  def prep_align(mix_df, ref_df, n_keep=None, log1p=False):
      idx = mix_df.index.intersection(ref_df.index)
      mix_df = mix_df.loc[idx, :].astype(float)
      ref_df = ref_df.loc[idx, :].astype(float)

      keep = select_top_var(ref_df, n_keep)
      keep = keep.intersection(mix_df.index)
      mix_df = mix_df.loc[keep, :]
      ref_df = ref_df.loc[keep, :]

      if log1p:
          mix_df = np.log1p(mix_df)
          ref_df = np.log1p(ref_df)

      scale = ref_df.mean(axis=1).replace(0, np.nan).fillna(1.0)
      mix_df = mix_df.div(scale, axis=0)
      ref_df = ref_df.div(scale, axis=0)
      return mix_df, ref_df

  def solve_simplex_ls(G, c):
      # Minimize p^T G p - 2 p^T c  s.t. p>=0, sum(p)=1
      K = G.shape[0]
      best_p = None
      best_obj = None
      one = np.ones(1, dtype=float)

      for mask in range(1, 1 << K):
          S = [i for i in range(K) if (mask >> i) & 1]
          k = len(S)
          GS = G[np.ix_(S, S)]
          cS = c[S]

          # KKT system:
          # [2GS  1][p ] = [2cS]
          # [1^T  0][lam]   [1  ]
          M = np.zeros((k + 1, k + 1), dtype=float)
          M[:k, :k] = 2.0 * GS
          M[:k, k] = 1.0
          M[k, :k] = 1.0

          rhs = np.zeros((k + 1,), dtype=float)
          rhs[:k] = 2.0 * cS
          rhs[k] = 1.0

          try:
              sol = np.linalg.solve(M, rhs)
          except np.linalg.LinAlgError:
              continue

          pS = sol[:k]
          if np.min(pS) < -1e-10:
              continue

          # objective (constant term ignored)
          obj = float(pS @ (GS @ pS) - 2.0 * (pS @ cS))
          if (best_obj is None) or (obj < best_obj):
              best_obj = obj
              p = np.zeros((K,), dtype=float)
              p[S] = pS
              best_p = p

      if best_p is None:
          # fallback: uniform
          best_p = np.ones((K,), dtype=float) / K

      best_p = np.maximum(best_p, 0.0) + EPS
      best_p = best_p / best_p.sum()
      return best_p

  # --- Prepare RNA ---
  mix_rna, ref_rna = prep_align(mix, ref, n_keep=N_RNA, log1p=True)
  Rr = ref_rna.to_numpy(dtype=float)          # (Fr x K)
  samples = list(mix.columns)
  celltypes = list(ref.columns)
  K = len(celltypes)

  # --- Prepare MET (optional) ---
  mix_met = kwargs.get("mix_met", None)
  ref_met = kwargs.get("ref_met", None)
  has_met = (mix_met is not None) and (ref_met is not None)

  if has_met:
      mix_m, ref_m = prep_align(mix_met, ref_met, n_keep=N_MET, log1p=False)
      Rm = ref_m.to_numpy(dtype=float)        # (Fm x K)
      met_samples = set(mix_m.columns)
  else:
      Rm = None
      met_samples = set()

  # weights to balance modalities
  Fr = Rr.shape[0]
  ar = 1.0 / np.sqrt(Fr + 1e-12)

  if has_met:
      Fm = Rm.shape[0]
      am = MET_W / np.sqrt(Fm + 1e-12)
      Gr = (ar * ar) * (Rr.T @ Rr)
      Gm = (am * am) * (Rm.T @ Rm)
  else:
      Gr = (ar * ar) * (Rr.T @ Rr)
      Gm = None

  # --- Solve per sample ---
  props = []
  for s in samples:
      yr = mix_rna[s].to_numpy(dtype=float)
      cr = (ar * ar) * (Rr.T @ yr)

      G = Gr.copy()
      c = cr.copy()

      if has_met and (s in met_samples):
          ym = mix_m[s].to_numpy(dtype=float)
          cm = (am * am) * (Rm.T @ ym)
          c = c + cm
          G = G + Gm

      p = solve_simplex_ls(G, c)
      props.append(p)

  prop = pd.DataFrame(props, index=samples, columns=celltypes).T
  prop = normalize(prop)
  prop.columns = mix.columns
  return prop


  ##
  ## YOUR CODE ENDS HERE
  ##
