def program(mix=None, ref=None, **kwargs):

  import os
  import numpy as np
  import pandas as pd
  from scipy.optimize import nnls

  EPS = 1e-8
  N_RNA = 1500
  N_MET = 4000

  # Calibration knobs
  CAL_ALPHA = 0.8        # try 0.6 / 0.8 / 0.9
  RIDGE_ALPHA = 1e-3     # try 1e-3 / 1e-2
  CAL_EPS = 1e-12

  def normalize(P):
      P = P.clip(lower=EPS)
      P = P.div(P.sum(axis=0), axis=1)
      P = P.fillna(1.0 / P.shape[0])
      P = P.div(P.sum(axis=0), axis=1)
      return P

  def select_features(ref_df, n_keep):
      if n_keep is None or n_keep >= ref_df.shape[0]:
          return ref_df.index
      v = ref_df.var(axis=1)
      return v.sort_values(ascending=False).head(n_keep).index

  def prep_align(mix_df, ref_df, n_keep=None, log1p=False):
      idx = mix_df.index.intersection(ref_df.index)
      mix_df = mix_df.loc[idx, :].astype(float)
      ref_df = ref_df.loc[idx, :].astype(float)

      keep = select_features(ref_df, n_keep)
      keep = keep.intersection(mix_df.index)
      mix_df = mix_df.loc[keep, :]
      ref_df = ref_df.loc[keep, :]

      if log1p:
          mix_df = np.log1p(mix_df)
          ref_df = np.log1p(ref_df)

      scale = ref_df.mean(axis=1).replace(0, np.nan).fillna(1.0)
      mix_df = mix_df.div(scale, axis=0)
      ref_df = ref_df.div(scale, axis=0)
      return mix_df, ref_df

  def nnls_deconv(mix_df, ref_df):
      R = ref_df.to_numpy(dtype=float)
      celltypes = list(ref_df.columns)

      props = []
      errs = []
      for s in mix_df.columns:
          y = mix_df[s].to_numpy(dtype=float)
          p, _ = nnls(R, y)
          p = np.maximum(p, 0.0) + EPS
          p = p / p.sum()

          yhat = R @ p
          err = np.linalg.norm(yhat - y) / (np.linalg.norm(y) + 1e-12)

          props.append(p)
          errs.append(err)

      P = pd.DataFrame(props, index=mix_df.columns, columns=celltypes).T
      E = pd.Series(errs, index=mix_df.columns)
      return P, E

  def base_predict(mix_rna, ref_rna, mix_met, ref_met):
      # RNA
      mix_rna2, ref_rna2 = prep_align(mix_rna, ref_rna, n_keep=N_RNA, log1p=True)
      P_rna, E_rna = nnls_deconv(mix_rna2, ref_rna2)
      P_rna = normalize(P_rna)

      out = P_rna.reindex(columns=mix_rna.columns)
      out = normalize(out)

      # MET optional
      if mix_met is None or ref_met is None:
          return out

      mix_m, ref_m = prep_align(mix_met, ref_met, n_keep=N_MET, log1p=False)
      P_met, E_met = nnls_deconv(mix_m, ref_m)
      P_met = normalize(P_met)

      common = out.columns.intersection(P_met.columns)
      if len(common) > 0:
          er = E_rna.reindex(common).fillna(E_rna.max() if len(E_rna) else 1.0)
          em = E_met.reindex(common).fillna(E_met.max() if len(E_met) else 1.0)

          wr = 1.0 / (er + 1e-12)
          wm = 1.0 / (em + 1e-12)
          wsum = wr + wm

          fused = out.loc[:, common].mul((wr / wsum), axis=1) + P_met.loc[:, common].mul((wm / wsum), axis=1)
          fused = normalize(fused)
          out.loc[:, common] = fused

      out = normalize(out)
      return out

  def clr(P, eps=1e-12):
      X = np.log(np.clip(P.to_numpy(float), eps, None))
      X = X - X.mean(axis=0, keepdims=True)
      return X

  def inv_clr(X):
      Y = np.exp(X)
      Y = Y / (Y.sum(axis=0, keepdims=True) + 1e-12)
      return Y

  def calib_paths():
      # try relative to current working dir and relative to this file
      p1 = os.path.join("attachement", "calibration_params.npz")
      p2 = os.path.join(os.path.dirname(__file__), "attachement", "calibration_params.npz")
      if os.path.exists(os.path.dirname(__file__)):
          return p1, p2
      return p1, p1

  def load_calibration():
      p1, p2 = calib_paths()
      path = p1 if os.path.exists(p1) else (p2 if os.path.exists(p2) else None)
      if path is None:
          return None
      z = np.load(path, allow_pickle=False)
      A = z["A"].astype(float)
      b = z["b"].astype(float)
      return A, b

  def save_calibration(A, b):
      p1, p2 = calib_paths()
      path = p1
      # ensure folder exists
      folder = os.path.dirname(path)
      if folder and (not os.path.exists(folder)):
          os.makedirs(folder, exist_ok=True)
      np.savez(path, A=A, b=b)

  def train_and_save_calibration(ref_rna, ref_met):
      # Train only if local folders exist
      if not (os.path.isdir("data") and os.path.isdir("ground_truth")):
          return None

   
      import attachement.data_processing as dp
      from sklearn.linear_model import Ridge


      celltypes = list(ref_rna.columns)
      allow = set(["SBN5", "SDN5", "SDC5", "SDE5", "SDEL", "VITR"])

      X_list = []
      Y_list = []

      for fn in sorted(os.listdir("data")):
          if not (fn.startswith("mixes_") and fn.endswith(".h5")):
              continue
          name = fn.replace("mixes_", "").replace(".h5", "")
          if name not in allow:
              continue

          mix_path = os.path.join("data", fn)
          gt_path = os.path.join("ground_truth", "groundtruth_" + name + ".h5")
          if not os.path.exists(gt_path):
              continue

          mixes = dp.read_hdf5(mix_path)
          gt_obj = dp.read_hdf5(gt_path)
          gt = gt_obj["groundtruth"] if "groundtruth" in gt_obj else None
          if gt is None:
              continue

          mix_rna = mixes["mix_rna"]
          mix_met = mixes.get("mix_met", None)

          # ensure gt columns are sample names
          if gt.shape[1] == mix_rna.shape[1]:
              gt.columns = list(mix_rna.columns)

          if not set(celltypes).issubset(set(gt.index)):
              continue

          gt5 = gt.loc[celltypes, :].astype(float)
          gt5 = gt5.clip(lower=CAL_EPS)
          gt5 = gt5.div(gt5.sum(axis=0), axis=1)

          Pbase = base_predict(mix_rna, ref_rna, mix_met, ref_met)
          Pbase = Pbase.loc[celltypes, :]
          Pbase = Pbase.clip(lower=CAL_EPS)
          Pbase = Pbase.div(Pbase.sum(axis=0), axis=1)

          X = clr(Pbase, eps=CAL_EPS).T  # (samples x 5)
          Y = clr(gt5, eps=CAL_EPS).T    # (samples x 5)

          X_list.append(X)
          Y_list.append(Y)

      if len(X_list) == 0:
          return None

      X_all = np.vstack(X_list)
      Y_all = np.vstack(Y_list)

      model = Ridge(alpha=RIDGE_ALPHA, fit_intercept=True)
      model.fit(X_all, Y_all)

      A = model.coef_.astype(float)       # (5 x 5)
      b = model.intercept_.astype(float)  # (5,)
      save_calibration(A, b)
      return A, b

  def apply_calibration(Pbase, A, b):
      X = clr(Pbase, eps=CAL_EPS)
      Y = (A @ X) + b[:, None]
      Pcal = inv_clr(Y)
      Pcal = pd.DataFrame(Pcal, index=Pbase.index, columns=Pbase.columns)
      Pmix = CAL_ALPHA * Pcal + (1.0 - CAL_ALPHA) * Pbase
      return normalize(Pmix)

  # ----- MAIN -----
  mix_met = kwargs.get("mix_met", None)
  ref_met = kwargs.get("ref_met", None)

  out = base_predict(mix, ref, mix_met, ref_met)

  # load calibration; if missing, train locally and save into attachement/
  calib = load_calibration()
  if calib is None:
      calib = train_and_save_calibration(ref, ref_met)

  if calib is not None:
      A, b = calib
      if (A.shape[0] == out.shape[0]) and (A.shape[1] == out.shape[0]) and (b.shape[0] == out.shape[0]):
          out = apply_calibration(out, A, b)

  out = normalize(out)
  out.columns = mix.columns
  return out

  ##
  ## YOUR CODE ENDS HERE
  ##
