def program(mix=None, ref=None, **kwargs):

  import numpy as np
  import pandas as pd
  from scipy.optimize import nnls

  EPS = 1e-9
  N_RNA = 1800
  N_MET = 9000
  USE_WEIGHT = True

  def normalize(P):
      P = P.clip(lower=EPS)
      s = P.sum(axis=0)
      s = s.replace(0, np.nan)
      P = P.div(s, axis=1)
      # if a column becomes NaN (rare), put uniform
      P = P.fillna(1.0 / P.shape[0])
      P = P.div(P.sum(axis=0), axis=1)
      return P

  def select_top_var(ref_df, n_keep):
      if n_keep is None or n_keep >= ref_df.shape[0]:
          return ref_df.index
      v = ref_df.var(axis=1)
      return v.sort_values(ascending=False).head(n_keep).index

  def prep_align(mix_df, ref_df, n_keep=None, log1p=False):
      idx = mix_df.index.intersection(ref_df.index)
      mix_df = mix_df.loc[idx, :].astype(float)
      ref_df = ref_df.loc[idx, :].astype(float)

      keep = select_top_var(ref_df, n_keep)
      keep = keep.intersection(mix_df.index)
      mix_df = mix_df.loc[keep, :]
      ref_df = ref_df.loc[keep, :]

      if log1p:
          mix_df = np.log1p(mix_df)
          ref_df = np.log1p(ref_df)

      if USE_WEIGHT:
          std = ref_df.std(axis=1).to_numpy(dtype=float)
          med = float(np.median(std) + 1e-12)
          w = std / med
          w = np.clip(w, 0.2, 5.0)
          mix_df = mix_df.mul(w, axis=0)
          ref_df = ref_df.mul(w, axis=0)

      scale = ref_df.mean(axis=1).replace(0, np.nan).fillna(1.0)
      mix_df = mix_df.div(scale, axis=0)
      ref_df = ref_df.div(scale, axis=0)
      return mix_df, ref_df

  def nnls_deconv(mix_df, ref_df):
      R = ref_df.to_numpy(dtype=float)
      celltypes = list(ref_df.columns)

      props = []
      errs = []
      for s in mix_df.columns:
          y = mix_df[s].to_numpy(dtype=float)
          p, _ = nnls(R, y)
          p = np.maximum(p, 0.0) + EPS
          p = p / p.sum()

          yhat = R @ p
          err = np.linalg.norm(yhat - y) / (np.linalg.norm(y) + 1e-12)

          props.append(p)
          errs.append(err)

      P = pd.DataFrame(props, index=mix_df.columns, columns=celltypes).T
      E = pd.Series(errs, index=mix_df.columns)
      return P, E

  def fuse_safe(P_rna, E_rna, P_met, E_met, all_cols):
      # Always start from RNA predictions for ALL samples
      out = P_rna.reindex(columns=all_cols).copy()
      out = normalize(out)

      if P_met is None or E_met is None:
          return out

      common = out.columns.intersection(P_met.columns)
      if len(common) == 0:
          return out

      e1 = E_rna.reindex(common).fillna(E_rna.max() if len(E_rna) else 1.0)
      e2 = E_met.reindex(common).fillna(E_met.max() if len(E_met) else 1.0)

      w_rna = e2 / (e1 + e2 + 1e-12)  # if met bad -> trust rna
      fused = out.loc[:, common].mul(w_rna, axis=1) + normalize(P_met.loc[:, common]).mul(1.0 - w_rna, axis=1)
      fused = normalize(fused)

      out.loc[:, common] = fused.loc[:, common]
      out = normalize(out)
      return out

  # --- RNA raw + log1p, then fuse them by error ---
  mix_rna_raw, ref_rna_raw = prep_align(mix, ref, n_keep=N_RNA, log1p=False)
  P_rna_raw, E_rna_raw = nnls_deconv(mix_rna_raw, ref_rna_raw)

  mix_rna_log, ref_rna_log = prep_align(mix, ref, n_keep=N_RNA, log1p=True)
  P_rna_log, E_rna_log = nnls_deconv(mix_rna_log, ref_rna_log)

  # choose per-sample: use the better of raw/log (lower error)
  all_cols = mix.columns
  E_rna = pd.concat([E_rna_raw.reindex(all_cols), E_rna_log.reindex(all_cols)], axis=1).min(axis=1)

  # build RNA prediction starting from log, but replace samples where raw is better
  P_rna = P_rna_log.reindex(columns=all_cols).copy()
  better_raw = (E_rna_raw.reindex(all_cols) < E_rna_log.reindex(all_cols)).fillna(False)
  cols_raw = list(better_raw[better_raw].index)
  if len(cols_raw) > 0:
      P_rna.loc[:, cols_raw] = P_rna_raw.reindex(columns=all_cols).loc[:, cols_raw]
  P_rna = normalize(P_rna)

  # --- MET ---
  mix_met = kwargs.get("mix_met", None)
  ref_met = kwargs.get("ref_met", None)

  if mix_met is None or ref_met is None:
      prop = P_rna
  else:
      mix_m, ref_m = prep_align(mix_met, ref_met, n_keep=N_MET, log1p=False)
      P_met, E_met = nnls_deconv(mix_m, ref_m)
      prop = fuse_safe(P_rna, E_rna, P_met, E_met, all_cols)

  prop.columns = mix.columns
  return prop

  ##
  ## YOUR CODE ENDS HERE
  ##
