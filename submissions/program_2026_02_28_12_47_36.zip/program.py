def program(mix=None, ref=None, **kwargs):

  ##
  ## YOUR CODE BEGINS HERE
  ##

  import os
  import numpy as np
  import pandas as pd
  from scipy.optimize import nnls, minimize
  from sklearn.linear_model import Ridge

  # ---- HYPER-PARAMETERS ----
  EPS         = 1e-6
  CAL_EPS     = 1e-12
  CAL_ALPHA   = 0.85
  RIDGE_ALPHA = 1e-2
  N_MET       = 3000

  # Three RNA feature subsets for ensemble (n_genes, selection_method)
  RNA_SUBSETS = [
      (600,  'specificity'),
      (900,  'specificity'),
      (600,  'fstat'),
  ]

  # ---- UTILITIES ----
  def normalize(P):
      P = P.clip(lower=EPS)
      P = P.div(P.sum(axis=0), axis=1)
      P = P.fillna(1.0 / P.shape[0])
      P = P.div(P.sum(axis=0), axis=1)
      return P

  def clr(P, eps=1e-12):
      X = np.log(np.clip(P.to_numpy(float), eps, None))
      X = X - X.mean(axis=0, keepdims=True)
      return X

  def inv_clr(X):
      Y = np.exp(X)
      Y = Y / (Y.sum(axis=0, keepdims=True) + 1e-12)
      return Y

  def geo_mean_proportions(prop_list, weights=None):
      """Average proportion DataFrames in CLR space (= compositionally correct average)."""
      if weights is None:
          weights = [1.0 / len(prop_list)] * len(prop_list)
      log_sum = None
      for P, w in zip(prop_list, weights):
          L = np.log(np.clip(P.to_numpy(float), EPS, None))
          log_sum = L * w if log_sum is None else log_sum + L * w
      Y = np.exp(log_sum)
      Y = Y / (Y.sum(axis=0, keepdims=True) + 1e-12)
      return pd.DataFrame(Y, index=prop_list[0].index, columns=prop_list[0].columns)

  # ---- FEATURE SELECTION ----
  def select_features_specificity(ref_df, n_keep):
      """Max/mean ratio � CV: selects marker genes expressed highly in exactly one type."""
      if n_keep is None or n_keep >= ref_df.shape[0]:
          return ref_df.index
      R = ref_df.to_numpy(float)
      gene_max  = R.max(axis=1)
      gene_mean = R.mean(axis=1) + 1e-8
      gene_std  = R.std(axis=1)
      score = (gene_max / gene_mean) * (gene_std / gene_mean)
      return pd.Series(score, index=ref_df.index).sort_values(ascending=False).head(n_keep).index

  def select_features_fstat(ref_df, n_keep):
      """F-statistic: between-group variance / within-group variance proxy."""
      if n_keep is None or n_keep >= ref_df.shape[0]:
          return ref_df.index
      R = ref_df.to_numpy(float)
      overall_mean = R.mean(axis=1, keepdims=True)
      between_var  = ((R - overall_mean) ** 2).mean(axis=1)
      within_var   = R.std(axis=1) + 1e-8
      score = between_var / within_var
      return pd.Series(score, index=ref_df.index).sort_values(ascending=False).head(n_keep).index

  # ---- PREPROCESSING ----
  def prep_align(mix_df, ref_df, n_keep=None, log1p=True, feature_method='specificity'):
      idx    = mix_df.index.intersection(ref_df.index)
      mix_df = mix_df.loc[idx, :].astype(float)
      ref_df = ref_df.loc[idx, :].astype(float)

      if feature_method == 'fstat':
          keep = select_features_fstat(ref_df, n_keep)
      else:
          keep = select_features_specificity(ref_df, n_keep)

      keep   = keep.intersection(mix_df.index)
      mix_df = mix_df.loc[keep, :]
      ref_df = ref_df.loc[keep, :]

      if log1p:
          mix_df = np.log1p(mix_df)
          ref_df = np.log1p(ref_df)

      scale  = ref_df.mean(axis=1).replace(0, np.nan).fillna(1.0)
      mix_df = mix_df.div(scale, axis=0)
      ref_df = ref_df.div(scale, axis=0)
      return mix_df, ref_df

  # ---- SOLVERS ----
  def qp_deconv(mix_df, ref_df):
      """
      Constrained quadratic programming deconvolution.
      Solves: min ||Rp - y||^2  subject to  p >= 0,  sum(p) = 1
      This is the true proportions problem � no post-hoc normalisation needed.
      Better Aitchison distance + lower MAE vs unconstrained NNLS.
      """
      R         = ref_df.to_numpy(dtype=float)
      n_types   = R.shape[1]
      celltypes = list(ref_df.columns)

      # Pre-compute Gram matrix once per dataset
      RtR = R.T @ R

      props, errs = [], []
      p0 = np.ones(n_types) / n_types   # uniform start

      for s in mix_df.columns:
          y   = mix_df[s].to_numpy(dtype=float)
          Rty = R.T @ y

          try:
              result = minimize(
                  fun=lambda p: float(p @ RtR @ p - 2.0 * (Rty @ p)),
                  x0=p0.copy(),
                  jac=lambda p: 2.0 * (RtR @ p) - 2.0 * Rty,
                  method='SLSQP',
                  bounds=[(0.0, 1.0)] * n_types,
                  constraints={
                      'type': 'eq',
                      'fun':  lambda p: p.sum() - 1.0,
                      'jac':  lambda p: np.ones(n_types)
                  },
                  options={'ftol': 1e-10, 'maxiter': 2000}
              )
              p = np.maximum(result.x, 0.0) + EPS
          except Exception:
              # Fallback: plain NNLS
              p, _ = nnls(R, y)
              p = np.maximum(p, 0.0) + EPS

          p /= p.sum()
          err = np.linalg.norm(R @ p - y) / (np.linalg.norm(y) + 1e-12)
          props.append(p)
          errs.append(err)

      P = pd.DataFrame(props, index=mix_df.columns, columns=celltypes).T
      E = pd.Series(errs, index=mix_df.columns)
      return P, E

  def nnls_deconv(mix_df, ref_df):
      """Plain NNLS � used as secondary solver in the ensemble."""
      R         = ref_df.to_numpy(dtype=float)
      celltypes = list(ref_df.columns)
      props, errs = [], []
      for s in mix_df.columns:
          y    = mix_df[s].to_numpy(dtype=float)
          p, _ = nnls(R, y)
          p    = np.maximum(p, 0.0) + EPS
          p   /= p.sum()
          err  = np.linalg.norm(R @ p - y) / (np.linalg.norm(y) + 1e-12)
          props.append(p)
          errs.append(err)
      P = pd.DataFrame(props, index=mix_df.columns, columns=celltypes).T
      E = pd.Series(errs, index=mix_df.columns)
      return P, E

  # ---- BASE PREDICTION ----
  def base_predict(mix_rna, ref_rna, mix_met, ref_met):

      # === RNA: ensemble of 3 feature subsets ===
      rna_props = []
      rna_errs  = []

      for n_keep, method in RNA_SUBSETS:
          mix_r, ref_r = prep_align(mix_rna, ref_rna, n_keep=n_keep,
                                     log1p=True, feature_method=method)
          P_qp, E_qp = qp_deconv(mix_r, ref_r)
          P_nn, E_nn = nnls_deconv(mix_r, ref_r)

          # Blend QP (primary) and NNLS (secondary) for this subset
          P_sub = geo_mean_proportions(
              [normalize(P_qp), normalize(P_nn)], weights=[0.70, 0.30]
          )
          E_sub = 0.70 * E_qp + 0.30 * E_nn
          rna_props.append(normalize(P_sub))
          rna_errs.append(E_sub)

      # Average all subsets in CLR space (equal weights)
      P_rna = geo_mean_proportions(rna_props)
      E_rna = pd.concat(rna_errs, axis=1).mean(axis=1)

      P_rna = normalize(P_rna)
      out   = P_rna.reindex(columns=mix_rna.columns)
      out   = normalize(out)

      # === Methylation (optional) ===
      if mix_met is None or ref_met is None:
          return out, E_rna

      mix_m, ref_m = prep_align(mix_met, ref_met, n_keep=N_MET,
                                 log1p=False, feature_method='fstat')
      P_met_qp, E_met_qp = qp_deconv(mix_m, ref_m)
      P_met_nn, E_met_nn = nnls_deconv(mix_m, ref_m)
      P_met = geo_mean_proportions(
          [normalize(P_met_qp), normalize(P_met_nn)], weights=[0.70, 0.30]
      )
      E_met = 0.70 * E_met_qp + 0.30 * E_met_nn
      P_met = normalize(P_met)

      # Fuse RNA + methylation in log space (Aitchison-correct)
      common = out.columns.intersection(P_met.columns)
      if len(common) > 0:
          er   = E_rna.reindex(common).fillna(E_rna.max() if len(E_rna) else 1.0)
          em   = E_met.reindex(common).fillna(E_met.max() if len(E_met) else 1.0)
          wr   = 1.0 / (er + 1e-12)
          wm   = 1.0 / (em + 1e-12)
          wsum = wr + wm

          log_rna   = np.log(np.clip(out.loc[:, common].to_numpy(float), EPS, None))
          log_met   = np.log(np.clip(P_met.loc[:, common].to_numpy(float), EPS, None))
          log_fused = log_rna * (wr / wsum).to_numpy() + log_met * (wm / wsum).to_numpy()
          fused     = np.exp(log_fused)
          fused    /= fused.sum(axis=0, keepdims=True) + 1e-12
          out.loc[:, common] = pd.DataFrame(fused, index=out.index, columns=common)

      return normalize(out), E_rna

  # ---- CALIBRATION ----
  def calib_paths():
      p1 = os.path.join("attachement", "calibration_params.npz")
      p2 = os.path.join(os.path.dirname(__file__), "attachement", "calibration_params.npz")
      if os.path.exists(os.path.dirname(__file__)):
          return p1, p2
      return p1, p1

  def load_calibration():
      p1, p2 = calib_paths()
      path = p1 if os.path.exists(p1) else (p2 if os.path.exists(p2) else None)
      if path is None:
          return None
      z = np.load(path, allow_pickle=False)
      return z["A"].astype(float), z["b"].astype(float)

  def save_calibration(A, b):
      p1, _ = calib_paths()
      folder = os.path.dirname(p1)
      if folder and not os.path.exists(folder):
          os.makedirs(folder, exist_ok=True)
      np.savez(p1, A=A, b=b)

  def train_and_save_calibration(ref_rna, ref_met):
      if not (os.path.isdir("data") and os.path.isdir("ground_truth")):
          return None

      import attachement.data_processing as dp

      celltypes = list(ref_rna.columns)
      allow     = {"SBN5", "SDN5", "SDC5", "SDE5", "SDEL", "VITR"}
      X_list, Y_list = [], []

      for fn in sorted(os.listdir("data")):
          if not (fn.startswith("mixes_") and fn.endswith(".h5")):
              continue
          name = fn.replace("mixes_", "").replace(".h5", "")
          if name not in allow:
              continue
          mix_path = os.path.join("data", fn)
          gt_path  = os.path.join("ground_truth", "groundtruth_" + name + ".h5")
          if not os.path.exists(gt_path):
              continue

          mixes  = dp.read_hdf5(mix_path)
          gt_obj = dp.read_hdf5(gt_path)
          gt     = gt_obj.get("groundtruth", None)
          if gt is None:
              continue

          mix_rna = mixes["mix_rna"]
          mix_met = mixes.get("mix_met", None)

          if gt.shape[1] == mix_rna.shape[1]:
              gt.columns = list(mix_rna.columns)
          if not set(celltypes).issubset(set(gt.index)):
              continue

          gt5 = gt.loc[celltypes, :].astype(float).clip(lower=CAL_EPS)
          gt5 = gt5.div(gt5.sum(axis=0), axis=1)

          Pbase, _ = base_predict(mix_rna, ref_rna, mix_met, ref_met)
          Pbase    = Pbase.loc[celltypes, :].clip(lower=CAL_EPS)
          Pbase    = Pbase.div(Pbase.sum(axis=0), axis=1)

          X_list.append(clr(Pbase, eps=CAL_EPS).T)
          Y_list.append(clr(gt5,   eps=CAL_EPS).T)

      if not X_list:
          return None

      X_all = np.vstack(X_list)
      Y_all = np.vstack(Y_list)

      model = Ridge(alpha=RIDGE_ALPHA, fit_intercept=True)
      model.fit(X_all, Y_all)
      A = model.coef_.astype(float)
      b = model.intercept_.astype(float)
      save_calibration(A, b)
      return A, b

  def apply_calibration(Pbase, A, b):
      X    = clr(Pbase, eps=CAL_EPS)
      Y    = (A @ X) + b[:, None]
      Pcal = inv_clr(Y)
      Pcal = pd.DataFrame(Pcal, index=Pbase.index, columns=Pbase.columns)
      Pmix = CAL_ALPHA * Pcal + (1.0 - CAL_ALPHA) * Pbase
      return normalize(Pmix)

  # ---- MAIN ----
  mix_met = kwargs.get("mix_met", None)
  ref_met = kwargs.get("ref_met", None)

  out, _ = base_predict(mix, ref, mix_met, ref_met)

  # Load or train calibration
  calib = load_calibration()
  if calib is None:
      calib = train_and_save_calibration(ref, ref_met)

  if calib is not None:
      A, b = calib
      if A.shape == (out.shape[0], out.shape[0]) and b.shape[0] == out.shape[0]:
          out = apply_calibration(out, A, b)

  out = normalize(out)
  out.columns = mix.columns
  return out

  ##
  ## YOUR CODE ENDS HERE
  ##
