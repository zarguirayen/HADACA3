def program(mix=None, ref=None, **kwargs):

  import numpy as np
  import pandas as pd
  from scipy.optimize import nnls

  # ---- r�glages (tu peux tester plusieurs valeurs) ----
  EPS = 1e-6
  N_RNA = 1500     # 800 / 1500 / 2500
  N_MET = 6000     # 2000 / 6000 / 12000

  def select_features(ref_df, n_keep):
      """Garde les features les plus variables entre les 5 types cellulaires (dans la r�f�rence)."""
      if n_keep is None or n_keep >= ref_df.shape[0]:
          return ref_df.index
      v = ref_df.var(axis=1)
      return v.sort_values(ascending=False).head(n_keep).index

  def prep_align(mix_df, ref_df, n_keep=None, log1p=False):
      """Aligne features mix/ref + s�lection + normalisation simple."""
      idx = mix_df.index.intersection(ref_df.index)
      mix_df = mix_df.loc[idx, :]
      ref_df = ref_df.loc[idx, :]

      keep = select_features(ref_df, n_keep)
      mix_df = mix_df.loc[keep, :]
      ref_df = ref_df.loc[keep, :]

      if log1p:
          mix_df = np.log1p(mix_df)
          ref_df = np.log1p(ref_df)

      # Normalisation par feature pour stabiliser
      scale = ref_df.mean(axis=1).replace(0, np.nan).fillna(1.0)
      mix_df = mix_df.div(scale, axis=0)
      ref_df = ref_df.div(scale, axis=0)

      return mix_df, ref_df

  def nnls_deconv(mix_df, ref_df):
      """NNLS par sample. Renvoie proportions (celltypes x samples) + erreur de reconstruction par sample."""
      R = ref_df.to_numpy(dtype=float)  # (features x celltypes)
      celltypes = list(ref_df.columns)

      props = []
      errs = []
      for j, sample in enumerate(mix_df.columns):
          y = mix_df.iloc[:, j].to_numpy(dtype=float)
          coef, _ = nnls(R, y)  # coef >= 0

          coef = np.maximum(coef, 0) + EPS
          coef = coef / coef.sum()

          # erreur relative (sert pour la fusion adaptative)
          yhat = R @ coef
          err = np.linalg.norm(yhat - y) / (np.linalg.norm(y) + 1e-12)

          props.append(coef)
          errs.append(err)

      prop_df = pd.DataFrame(props, index=mix_df.columns, columns=celltypes).T  # (celltypes x samples)
      err_s = pd.Series(errs, index=mix_df.columns)
      return prop_df, err_s

  # ---------------- RNA ----------------
  mix_rna, ref_rna = prep_align(mix, ref, n_keep=N_RNA, log1p=True)
  prop_rna, err_rna = nnls_deconv(mix_rna, ref_rna)

  # ------------- Methylome -------------
  prop_met, err_met = None, None
  if ("mix_met" in kwargs) and ("ref_met" in kwargs) and (kwargs["mix_met"] is not None) and (kwargs["ref_met"] is not None):
      mix_met, ref_met = prep_align(kwargs["mix_met"], kwargs["ref_met"], n_keep=N_MET, log1p=False)
      prop_met, err_met = nnls_deconv(mix_met, ref_met)

  # ---------------- Fusion ----------------
  if prop_met is None:
      prop = prop_rna
  else:
      # aligner sur les m�mes samples
      common_samples = prop_rna.columns.intersection(prop_met.columns)
      prop_rna2 = prop_rna.loc[:, common_samples]
      prop_met2 = prop_met.loc[:, common_samples]
      er = err_rna.loc[common_samples]
      em = err_met.loc[common_samples]

      # poids adaptatif : meilleure reconstruction => plus de poids
      wr = 1.0 / (er + 1e-12)
      wm = 1.0 / (em + 1e-12)
      wsum = (wr + wm)

      prop = prop_rna2.mul((wr / wsum), axis=1) + prop_met2.mul((wm / wsum), axis=1)

      # anti-z�ro + renormalisation
      prop = prop.clip(lower=EPS)
      prop = prop.div(prop.sum(axis=0), axis=1)

      # remettre dans l'ordre des colonnes du mix RNA
      prop = prop.reindex(columns=mix.columns)

  prop.columns = mix.columns
  return prop
  ##
  ## YOUR CODE ENDS HERE
  ##
