def program(mix=None, ref=None, **kwargs):

  import numpy as np
  import pandas as pd
  from scipy.optimize import nnls

  EPS = 1e-6
  N_RNA = 1500
  N_MET = 9000
  MET_LOGIT = True   # True = M-values (often better), False = beta

  def normalize(P):
      P = P.clip(lower=EPS)
      s = P.sum(axis=0)
      s = s.replace(0, np.nan)
      P = P.div(s, axis=1)
      P = P.fillna(1.0 / P.shape[0])
      P = P.div(P.sum(axis=0), axis=1)
      return P

  def select_markers_balanced(ref_df, n_total):
      # pick markers per cell type using specificity ratio
      n_ct = ref_df.shape[1]
      n_each = max(1, n_total // n_ct)

      A = ref_df.to_numpy(dtype=float)
      idx = ref_df.index
      picks = set()

      total = A.sum(axis=1) + 1e-12
      for k in range(n_ct):
          numer = A[:, k] + 1e-12
          denom = (total - A[:, k]) + 1e-12
          score = numer / denom
          top = np.argsort(-score)[:n_each]
          for t in top:
              picks.add(idx[t])

      # fill remaining with highest variance
      if len(picks) < n_total:
          v = ref_df.var(axis=1).sort_values(ascending=False)
          for f in v.index:
              picks.add(f)
              if len(picks) >= n_total:
                  break

      return pd.Index(list(picks))

  def to_logit_beta(df):
      x = df.to_numpy(dtype=float)
      x = np.clip(x, 1e-5, 1.0 - 1e-5)
      x = np.log(x / (1.0 - x))
      return pd.DataFrame(x, index=df.index, columns=df.columns)

  def prep_align(mix_df, ref_df, n_keep=None, log1p=False, logit=False):
      idx = mix_df.index.intersection(ref_df.index)
      mix_df = mix_df.loc[idx, :].astype(float)
      ref_df = ref_df.loc[idx, :].astype(float)

      keep = select_markers_balanced(ref_df, n_keep)
      keep = keep.intersection(mix_df.index)
      mix_df = mix_df.loc[keep, :]
      ref_df = ref_df.loc[keep, :]

      if log1p:
          mix_df = np.log1p(mix_df)
          ref_df = np.log1p(ref_df)

      if logit:
          mix_df = to_logit_beta(mix_df)
          ref_df = to_logit_beta(ref_df)

      # scale by abs mean ref (works even if values can be negative after logit)
      scale = ref_df.abs().mean(axis=1).replace(0, np.nan).fillna(1.0)
      mix_df = mix_df.div(scale, axis=0)
      ref_df = ref_df.div(scale, axis=0)
      return mix_df, ref_df

  def nnls_deconv(mix_df, ref_df):
      R = ref_df.to_numpy(dtype=float)
      celltypes = list(ref_df.columns)

      props = []
      errs = []
      for s in mix_df.columns:
          y = mix_df[s].to_numpy(dtype=float)
          p, _ = nnls(R, y)
          p = np.maximum(p, 0.0) + EPS
          p = p / p.sum()

          yhat = R @ p
          err = np.linalg.norm(yhat - y) / (np.linalg.norm(y) + 1e-12)

          props.append(p)
          errs.append(err)

      P = pd.DataFrame(props, index=mix_df.columns, columns=celltypes).T
      E = pd.Series(errs, index=mix_df.columns)
      return P, E

  # RNA (always)
  mix_rna, ref_rna = prep_align(mix, ref, n_keep=N_RNA, log1p=True, logit=False)
  P_rna, E_rna = nnls_deconv(mix_rna, ref_rna)
  P_rna = normalize(P_rna)

  # start from RNA for ALL samples
  out = P_rna.reindex(columns=mix.columns)
  out = normalize(out)

  # MET (optional)
  mix_met = kwargs.get("mix_met", None)
  ref_met = kwargs.get("ref_met", None)
  if mix_met is None or ref_met is None:
      out.columns = mix.columns
      return out

  mix_m, ref_m = prep_align(mix_met, ref_met, n_keep=N_MET, log1p=False, logit=MET_LOGIT)
  P_met, E_met = nnls_deconv(mix_m, ref_m)
  P_met = normalize(P_met)

  # fuse only on common samples
  common = out.columns.intersection(P_met.columns)
  if len(common) > 0:
      er = E_rna.reindex(common).fillna(E_rna.max() if len(E_rna) else 1.0)
      em = E_met.reindex(common).fillna(E_met.max() if len(E_met) else 1.0)

      wr = 1.0 / (er + 1e-12)
      wm = 1.0 / (em + 1e-12)
      wsum = wr + wm

      fused = out.loc[:, common].mul((wr / wsum), axis=1) + P_met.loc[:, common].mul((wm / wsum), axis=1)
      fused = normalize(fused)
      out.loc[:, common] = fused

  out = normalize(out)
  out.columns = mix.columns
  return out


  ##
  ## YOUR CODE ENDS HERE
  ##
