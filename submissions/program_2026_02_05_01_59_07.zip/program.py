def program(mix=None, ref=None, **kwargs):

  import numpy as np
  import pandas as pd
  from scipy.optimize import nnls

  EPS = 1e-6
  N_RNA = 1800   # try 1200 / 1800 / 2500
  N_MET = 8000   # try 4000 / 8000 / 12000

  def select_top_var(ref_df, n_keep):
      if n_keep is None or n_keep >= ref_df.shape[0]:
          return ref_df.index
      v = ref_df.var(axis=1)
      return v.sort_values(ascending=False).head(n_keep).index

  def prep_align(mix_df, ref_df, n_keep=None, log1p=False):
      idx = mix_df.index.intersection(ref_df.index)
      mix_df = mix_df.loc[idx, :].astype(float)
      ref_df = ref_df.loc[idx, :].astype(float)

      keep = select_top_var(ref_df, n_keep)
      keep = keep.intersection(mix_df.index)
      mix_df = mix_df.loc[keep, :]
      ref_df = ref_df.loc[keep, :]

      if log1p:
          mix_df = np.log1p(mix_df)
          ref_df = np.log1p(ref_df)

      # scale rows by mean ref signal to stabilize magnitude
      scale = ref_df.mean(axis=1).replace(0, np.nan).fillna(1.0)
      mix_df = mix_df.div(scale, axis=0)
      ref_df = ref_df.div(scale, axis=0)
      return mix_df, ref_df

  def nnls_deconv(mix_df, ref_df):
      R = ref_df.to_numpy(dtype=float)  # (features x celltypes)
      celltypes = list(ref_df.columns)

      props = np.zeros((len(celltypes), mix_df.shape[1]), dtype=float)
      errs = np.zeros(mix_df.shape[1], dtype=float)

      for j, s in enumerate(mix_df.columns):
          y = mix_df[s].to_numpy(dtype=float)
          p, _ = nnls(R, y)
          p = np.maximum(p, 0.0) + EPS
          p = p / p.sum()

          yhat = R @ p
          errs[j] = np.linalg.norm(yhat - y) / (np.linalg.norm(y) + 1e-12)
          props[:, j] = p

      P = pd.DataFrame(props, index=celltypes, columns=mix_df.columns)
      E = pd.Series(errs, index=mix_df.columns)
      return P, E

  def clr(P):
      # P: (celltypes x samples)
      X = np.log(np.clip(P.to_numpy(dtype=float), EPS, None))
      X = X - X.mean(axis=0, keepdims=True)
      return X

  def inv_clr(X, index, columns):
      Y = np.exp(X)
      Y = Y / Y.sum(axis=0, keepdims=True)
      return pd.DataFrame(Y, index=index, columns=columns)

  # --- RNA ---
  mix_rna, ref_rna = prep_align(mix, ref, n_keep=N_RNA, log1p=True)
  P_rna, E_rna = nnls_deconv(mix_rna, ref_rna)

  # --- MET ---
  mix_met = kwargs.get("mix_met", None)
  ref_met = kwargs.get("ref_met", None)

  if mix_met is None or ref_met is None:
      prop = P_rna
  else:
      mix_m, ref_m = prep_align(mix_met, ref_met, n_keep=N_MET, log1p=False)
      P_met, E_met = nnls_deconv(mix_m, ref_m)

      # align samples
      common = P_rna.columns.intersection(P_met.columns)
      P_rna = P_rna.loc[:, common]
      P_met = P_met.loc[:, common]
      er = E_rna.loc[common]
      em = E_met.loc[common]

      # weights (better reconstruction => higher weight)
      wr = 1.0 / (er + 1e-12)
      wm = 1.0 / (em + 1e-12)
      wsum = wr + wm
      wr = wr / wsum
      wm = wm / wsum

      # CLR fusion (good for Aitchison)
      Xr = clr(P_rna)
      Xm = clr(P_met)
      X = (Xr * wr.to_numpy()[None, :]) + (Xm * wm.to_numpy()[None, :])
      prop = inv_clr(X, index=ref.columns, columns=common)

      # put back full column order
      prop = prop.reindex(columns=mix.columns)

  prop = prop.clip(lower=EPS)
  prop = prop.div(prop.sum(axis=0), axis=1)
  prop.columns = mix.columns
  return prop
  ##
  ## YOUR CODE ENDS HERE
  ##
