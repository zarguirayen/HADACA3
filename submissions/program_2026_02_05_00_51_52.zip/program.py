def program(mix=None, ref=None, **kwargs):

  import numpy as np
  import pandas as pd
  from scipy.optimize import nnls

  EPS = 1e-6
  N_RNA = 1500
  N_MET = 6000

  def select_features(ref_df, n_keep):
      if n_keep is None or n_keep >= ref_df.shape[0]:
          return ref_df.index
      v = ref_df.var(axis=1)
      return v.sort_values(ascending=False).head(n_keep).index

  def prep_align(mix_df, ref_df, n_keep=None, log1p=False):
      # align features
      idx = mix_df.index.intersection(ref_df.index)
      mix_df = mix_df.loc[idx, :].astype(float)
      ref_df = ref_df.loc[idx, :].astype(float)

      # feature selection (most variable in reference)
      keep = select_features(ref_df, n_keep)
      mix_df = mix_df.loc[keep, :]
      ref_df = ref_df.loc[keep, :]

      if log1p:
          mix_df = np.log1p(mix_df)
          ref_df = np.log1p(ref_df)

      # simple scaling by mean reference signal
      scale = ref_df.mean(axis=1).replace(0, np.nan).fillna(1.0)
      mix_df = mix_df.div(scale, axis=0)
      ref_df = ref_df.div(scale, axis=0)

      return mix_df, ref_df

  def nnls_deconv(mix_df, ref_df):
      R = ref_df.to_numpy(dtype=float)  # (features x celltypes)
      celltypes = list(ref_df.columns)

      props = []
      errs = []
      for sample in mix_df.columns:
          y = mix_df[sample].to_numpy(dtype=float)
          coef, _ = nnls(R, y)

          coef = np.maximum(coef, 0) + EPS
          coef = coef / coef.sum()

          yhat = R @ coef
          err = np.linalg.norm(yhat - y) / (np.linalg.norm(y) + 1e-12)

          props.append(coef)
          errs.append(err)

      prop_df = pd.DataFrame(props, index=mix_df.columns, columns=celltypes).T
      err_s = pd.Series(errs, index=mix_df.columns)
      return prop_df, err_s

  # RNA
  mix_rna, ref_rna = prep_align(mix, ref, n_keep=N_RNA, log1p=True)
  prop_rna, err_rna = nnls_deconv(mix_rna, ref_rna)

  # Methylation
  mix_met = kwargs.get("mix_met", None)
  ref_met = kwargs.get("ref_met", None)

  if mix_met is None or ref_met is None:
      prop = prop_rna
  else:
      mix_met2, ref_met2 = prep_align(mix_met, ref_met, n_keep=N_MET, log1p=False)
      prop_met, err_met = nnls_deconv(mix_met2, ref_met2)

      # align samples
      common = prop_rna.columns.intersection(prop_met.columns)
      prop_rna = prop_rna.loc[:, common]
      prop_met = prop_met.loc[:, common]
      er = err_rna.loc[common]
      em = err_met.loc[common]

      # adaptive weights
      wr = 1.0 / (er + 1e-12)
      wm = 1.0 / (em + 1e-12)
      wsum = wr + wm

      prop = prop_rna.mul((wr / wsum), axis=1) + prop_met.mul((wm / wsum), axis=1)

      prop = prop.clip(lower=EPS)
      prop = prop.div(prop.sum(axis=0), axis=1)

      prop = prop.reindex(columns=mix.columns)

  prop.columns = mix.columns
  return prop
  ##
  ## YOUR CODE ENDS HERE
  ##
