def program(mix=None, ref=None, **kwargs):

  import numpy as np
  import pandas as pd
  from scipy.optimize import nnls

  EPS = 1e-6

  # Start with 2 settings (more stable). You can add a 3rd later.
  SETTINGS = [
      (1200, 5000),
      (2000, 9000),
  ]

  def select_markers_balanced(ref_df, n_total):
      n_ct = ref_df.shape[1]
      n_each = max(1, n_total // n_ct)

      A = ref_df.to_numpy(dtype=float)
      idx = ref_df.index
      picks = set()

      total = A.sum(axis=1) + 1e-12
      for k in range(n_ct):
          numer = A[:, k] + 1e-12
          denom = (total - A[:, k]) + 1e-12
          score = numer / denom
          top = np.argsort(-score)[:n_each]
          for t in top:
              picks.add(idx[t])

      # Fill remaining with highest variance
      if len(picks) < n_total:
          v = ref_df.var(axis=1).sort_values(ascending=False)
          for f in v.index:
              picks.add(f)
              if len(picks) >= n_total:
                  break

      return pd.Index(list(picks))

  def prep_align_weight(mix_df, ref_df, n_keep, log1p=False):
      # Align features
      idx = mix_df.index.intersection(ref_df.index)
      mix_df = mix_df.loc[idx, :].astype(float)
      ref_df = ref_df.loc[idx, :].astype(float)

      # Marker selection
      keep = select_markers_balanced(ref_df, n_keep)
      keep = keep.intersection(mix_df.index)
      mix_df = mix_df.loc[keep, :]
      ref_df = ref_df.loc[keep, :]

      if log1p:
          mix_df = np.log1p(mix_df)
          ref_df = np.log1p(ref_df)

      # CORRECT weighting: weight proportional to std (not inverse)
      std = ref_df.std(axis=1).to_numpy(dtype=float)
      med = float(np.median(std) + 1e-12)
      w = std / med
      w = np.clip(w, 0.2, 5.0)  # avoid extreme weights

      mix_df = mix_df.mul(w, axis=0)
      ref_df = ref_df.mul(w, axis=0)

      # Scale by mean ref to stabilize magnitude
      scale = ref_df.mean(axis=1).replace(0, np.nan).fillna(1.0)
      mix_df = mix_df.div(scale, axis=0)
      ref_df = ref_df.div(scale, axis=0)

      return mix_df, ref_df

  def nnls_all_samples(mix_df, ref_df):
      R = ref_df.to_numpy(dtype=float)
      props = []
      for s in mix_df.columns:
          y = mix_df[s].to_numpy(dtype=float)
          p, _ = nnls(R, y)
          p = np.maximum(p, 0) + EPS
          p = p / p.sum()
          props.append(p)
      P = pd.DataFrame(props, index=mix_df.columns, columns=ref_df.columns).T
      return P

  def joint_nnls_one_setting(mix_rna, ref_rna, mix_met, ref_met, n_rna, n_met):
      # Prep RNA
      Xr, Rr = prep_align_weight(mix_rna, ref_rna, n_keep=n_rna, log1p=True)

      # RNA-only baseline for all samples (used if met missing)
      P_rna = nnls_all_samples(Xr, Rr)
      P_rna = P_rna.reindex(columns=mix_rna.columns)

      if mix_met is None or ref_met is None:
          return P_rna

      # Prep methylation
      Xm, Rm = prep_align_weight(mix_met, ref_met, n_keep=n_met, log1p=False)

      # Common samples
      common = Xr.columns.intersection(Xm.columns)
      if len(common) == 0:
          return P_rna

      Xr_c = Xr.loc[:, common]
      Xm_c = Xm.loc[:, common]

      Rr_np = Rr.to_numpy(dtype=float)
      Rm_np = Rm.to_numpy(dtype=float)

      # Balance modalities by feature count
      wr = 1.0 / np.sqrt(Rr_np.shape[0])
      wm = 1.0 / np.sqrt(Rm_np.shape[0])

      A = np.vstack([wr * Rr_np, wm * Rm_np])

      props = []
      for s in common:
          yr = wr * Xr_c[s].to_numpy(dtype=float)
          ym = wm * Xm_c[s].to_numpy(dtype=float)
          y = np.concatenate([yr, ym], axis=0)

          p, _ = nnls(A, y)
          p = np.maximum(p, 0) + EPS
          p = p / p.sum()
          props.append(p)

      P_joint = pd.DataFrame(props, index=common, columns=Rr.columns).T

      # Merge: use joint for common samples, RNA-only otherwise
      P = P_rna.copy()
      P.loc[:, common] = P_joint.loc[:, common]

      P = P.clip(lower=EPS)
      P = P.div(P.sum(axis=0), axis=1)
      return P

  def clr(P):
      X = np.log(np.clip(P.to_numpy(dtype=float), EPS, None))
      X = X - X.mean(axis=0, keepdims=True)
      return X

  def inv_clr(X, index, columns):
      Y = np.exp(X)
      Y = Y / Y.sum(axis=0, keepdims=True)
      return pd.DataFrame(Y, index=index, columns=columns)

  mix_rna = mix
  ref_rna = ref
  mix_met = kwargs.get("mix_met", None)
  ref_met = kwargs.get("ref_met", None)

  clrs = []
  for (n_rna, n_met) in SETTINGS:
      P = joint_nnls_one_setting(mix_rna, ref_rna, mix_met, ref_met, n_rna, n_met)
      P = P.clip(lower=EPS)
      P = P.div(P.sum(axis=0), axis=1)
      clrs.append(clr(P))

  Xavg = np.mean(np.stack(clrs, axis=0), axis=0)
  prop = inv_clr(Xavg, index=ref_rna.columns, columns=mix_rna.columns)

  prop = prop.clip(lower=EPS)
  prop = prop.div(prop.sum(axis=0), axis=1)
  return prop
  ##
  ## YOUR CODE ENDS HERE
  ##
